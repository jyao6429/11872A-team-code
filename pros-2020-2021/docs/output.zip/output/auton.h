#ifndef AUTON_H
#define AUTON_H

namespace auton
{
    void skills();
    void skillsSafe();
    void frontHomeRow(int selection);
    void frontHalf(int selection);
    void backHalf(int selection);
}

#endif