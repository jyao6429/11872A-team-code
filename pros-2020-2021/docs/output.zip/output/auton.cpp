#include "main.h"

namespace auton
{
    void skills()
    {

    }
    void skillsSafe()
    {

    }
    void frontHomeRow(int selection)
    {

    }
    void frontHalf(int selection)
    {

    }
    void backHalf(int selection)
    {

    }
}