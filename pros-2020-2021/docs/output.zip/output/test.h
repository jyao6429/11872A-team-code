#ifndef TEST_H
#define TEST_H

namespace test
{
    /**
     * Runs the selected test case in test.cpp
     */
    void run();
}

#endif