#ifndef TEST_H
#define TEST_H

namespace test
{
    void run();
}

#endif