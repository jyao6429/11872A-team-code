#ifndef INDEXER_H
#define INDEXER_H

namespace indexer
{
    void moveVoltageSafe(int indexerVolt);
    void moveVoltage(int indexerVolt);
    void opcontrol();
}

#endif